<?php

	define('hostname',"20.0.0.11");
	define('username',"admin");
	define('password',"admin");
	define('dbname',"farmaciatst");

?>